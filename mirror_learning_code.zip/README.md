# mirror-learning
The code for experiments conducted to verify the correctness of mirror learning.

Experiment settings can be specified in config.py. To run the experiments, use run.py.
